const client = require("../index");

client.on("ready", () =>
    console.log(`${client.user.tag} has been successfully deployed!! 🚀`)
);